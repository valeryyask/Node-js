module.exports = {
  user: 'sttudent',
  password: 'xfitfit',
  server: 'DESKTOP-9KHC54T',
  database: 'UNIVER',
  options: {
    encrypt: false,
    enableArithAbort: true,
    trustServerCertificate: true
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
};