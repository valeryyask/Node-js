const fs = require('fs');
const path = require('path');

function StaticHandler(staticFolder = './static') {
    this.STATIC_FOLDER = staticFolder;
    
    const pathStatic = (filename) => path.join(__dirname, this.STATIC_FOLDER, filename);

    this.isStatic = (ext, url) => {
        const reg = new RegExp(`\/.+\\.${ext}$`);
        return reg.test(url);
    };

    this.writeHTTP404 = (res) => {
        res.statusCode = 404;
        res.statusMessage = 'Resource not found';
        res.end('Resource not found');
    };

    this.writeHTTP405 = (res) => {
        res.statusCode = 405;
        res.statusMessage = 'Method Not Allowed';
        res.end('Method Not Allowed');
    };

    const pipeFile = (req, res, headers) => {
        res.writeHead(200, headers);        
        fs.createReadStream(pathStatic(req.url)).pipe(res);
    };    

    this.sendFile = (req, res, headers) => {
        if (req.method !== 'GET') {
            return this.writeHTTP405(res);
        }

        fs.access(pathStatic(req.url), fs.constants.R_OK, err => {
            if (err) this.writeHTTP404(res);
            else pipeFile(req, res, headers);
        });
    };
}

module.exports = (param) => new StaticHandler(param);