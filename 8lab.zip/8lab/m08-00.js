const fs = require('fs');
const path = require('path');
const querystring = require('querystring');
const http = require('http');

function MainHandler(staticFolder = './static') {
    this.STATIC_FOLDER = staticFolder;
    
    const pathStatic = (filename) => path.join(__dirname, this.STATIC_FOLDER, filename);

    this.writeHTTP404 = (res) => {
        res.statusCode = 404;
        res.statusMessage = 'Resource not found';
        res.end('Resource not found');
    };

    this.writeHTTP405 = (res) => {
        res.statusCode = 405;
        res.statusMessage = 'Method Not Allowed';
        res.end('Method Not Allowed');
    };

    // 12-13
    this.getFilesCount = (callback) => {
        fs.readdir(pathStatic(''), (err, items) => {
            if (err) {
                callback(0);
                return;
            }

            let fileCount = 0;
            let itemsProcessed = 0;

            if (items.length === 0) {
                callback(0);
                return;
            }

            items.forEach(item => {
                const fullPath = pathStatic(item);
                
                fs.stat(fullPath, (err, stats) => {
                    if (!err && stats.isFile()) {
                        fileCount++;
                    }
                    
                    itemsProcessed++;
                    if (itemsProcessed === items.length) {
                        callback(fileCount);
                    }
                });
            });
        });
    };

    this.getAllFiles = (callback) => {
        fs.readdir(pathStatic(''), (err, items) => {
            if (err) {
                callback([]);
                return;
            }

            const files = [];
            let itemsProcessed = 0;

            if (items.length === 0) {
                callback([]);
                return;
            }

            items.forEach(item => {
                const fullPath = pathStatic(item);
                
                fs.stat(fullPath, (err, stats) => {
                    if (!err && stats.isFile()) {
                        files.push(item);
                    }
                    
                    itemsProcessed++;
                    if (itemsProcessed === items.length) {
                        callback(files);
                    }
                });
            });
        });
    };

    this.sendFileByName = (filename, res) => {
        const filePath = pathStatic(filename);
        
        fs.access(filePath, fs.constants.R_OK, err => {
            if (err) {
                this.writeHTTP404(res);
                return;
            }

            const ext = path.extname(filename).toLowerCase();
            const contentTypes = {
                '.html': 'text/html; charset=utf-8',
                '.css': 'text/css; charset=utf-8',
                '.js': 'text/javascript; charset=utf-8',
                '.json': 'application/json; charset=utf-8',
                '.xml': 'application/xml; charset=utf-8',
                '.png': 'image/png',
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.gif': 'image/gif',
                '.mp4': 'video/mp4',
                '.docx': 'application/msword',
                '.pdf': 'application/pdf',
                '.txt': 'text/plain; charset=utf-8'
            };

            const contentType = contentTypes[ext] || 'application/octet-stream';

            res.writeHead(200, {
                'Content-Type': contentType,
                'Content-Disposition': `inline; filename="${filename}"`
            });
            
            fs.createReadStream(filePath).pipe(res);
        });
    };

    this.getUploadForm = () => {
        return `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Загрузка файлов</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        form { border: 1px solid #ccc; padding: 20px; max-width: 500px; }
        input[type="file"] { margin: 10px 0; }
        input[type="submit"] { background: #007cba; color: white; padding: 10px 20px; border: none; cursor: pointer; }
        input[type="submit"]:hover { background: #005a87; }
        .message { margin: 10px 0; padding: 10px; border-radius: 4px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>
    <h1>Загрузка файлов на сервер</h1>
    <form method="POST" action="/upload" enctype="multipart/form-data">
        <p>Выберите файл для загрузки:</p>
        <input type="file" name="fileupload" required>
        <br>
        <input type="submit" value="Загрузить файл">
    </form>    
</body>
</html>`;
    };

    this.handleFileUpload = (req, res) => {
        let body = Buffer.alloc(0);
        
        req.on('data', chunk => {
            body = Buffer.concat([body, chunk]);
        });

        req.on('end', () => {
            const boundary = req.headers['content-type'].split('boundary=')[1];
            const parts = body.toString('binary').split('--' + boundary);
            
            for (let part of parts) {
                if (part.includes('filename="') && part.includes('Content-Type:')) {                    
                    const filenameMatch = part.match(/filename="([^"]*)"/);
                    if (!filenameMatch) continue;
                    
                    const filename = filenameMatch[1];
                    if (!filename) continue;

                    const fileDataMatch = part.split('\r\n\r\n')[1];
                    if (!fileDataMatch) continue;

                    const fileData = fileDataMatch.substring(0, fileDataMatch.lastIndexOf('\r\n'));
                    
                    const fileBuffer = Buffer.from(fileData, 'binary');
                    const filePath = pathStatic(filename);
                    
                    fs.writeFile(filePath, fileBuffer, (err) => {
                        if (err) {
                            console.log('Ошибка сохранения файла:', err);
                            res.writeHead(500, { 'Content-Type': 'text/html; charset=utf-8' });
                            res.end(`<div class="message error">Ошибка загрузки файла: ${err.message}</div><a href="/upload">Назад</a>`);
                        } else {
                            console.log(`Файл сохранен: ${filename}`);
                            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                            res.end(`<div class="message success">Файл "${filename}" успешно загружен!</div>`);
                        }
                    });
                    return;
                }
            }
                        
            res.writeHead(400, { 'Content-Type': 'text/html; charset=utf-8' });
            res.end(`<div class="message error">Файл не найден в запросе</div><a href="/upload">Назад</a>`);
        });
    };
}

module.exports = (param) => new MainHandler(param);