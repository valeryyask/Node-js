const http = require('http');
const url = require('url');
const querystring = require('querystring');
const mainHandler = require('./m08-00')('./static');

const server = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;
    const query = parsedUrl.query;

    // 01 /connection
    if (pathname === '/connection') {
        if (query.set !== undefined) {
            const newTimeout = parseInt(query.set);
            if (!isNaN(newTimeout)) {
                server.keepAliveTimeout = newTimeout;
                res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
                res.end(`Установлено новое значение параметра KeepAliveTimeout = ${newTimeout}`);
            } else {
                res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
                res.end('Ошибка: параметр set должен быть числом');
            }
        } else {
            res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end(`Текущее значение KeepAliveTimeout = ${server.keepAliveTimeout}`);
        }
    }

    // 02 /headers
    else if (pathname === '/headers') {        
        let responseText = 'ЗАГОЛОВКИ ЗАПРОСА\n';
        for (const [key, value] of Object.entries(req.headers)) {
            responseText += `${key}: ${value}\n`;
        }

        res.setHeader('X-PSKP-Server', 'Node.js-HTTP');
        res.setHeader('X-Student-Group', 'PI-3');
        res.setHeader('X-Custom-Header', 'Hello from PSKP Lab');
        
        res.writeHead(200, { 
            'Content-Type': 'text/plain; charset=utf-8',
            'Content-Language': 'ru'
        });
        
        responseText += '\nЗАГОЛОВКИ ОТВЕТА\n';
        const responseHeaders = res.getHeaders();
        for (const [key, value] of Object.entries(responseHeaders)) {
            responseText += `${key}: ${value}\n`;
        }

        res.end(responseText);
    }

    // 03 /parameter?x=x&y=y
    else if (pathname === '/parameter') {
        const x = query.x;
        const y = query.y;

        if (x === undefined || y === undefined) {
            res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Ошибка: передайте параметры x и y');
            return;
        }

        const numX = parseFloat(x);
        const numY = parseFloat(y);

        if (isNaN(numX) || isNaN(numY)) {
            res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Ошибка: параметры x и y должны быть числами');
            return;
        }

        const sum = numX + numY;
        const difference = numX - numY;
        const product = numX * numY;
        const quotient = numY !== 0 ? numX / numY : 'деление на ноль';
        
        const responseText = 
            `x = ${numX}, y = ${numY}\n\n` +
            `Сумма: ${numX} + ${numY} = ${sum}\n` +
            `Разность: ${numX} - ${numY} = ${difference}\n` +
            `Произведение: ${numX} * ${numY} = ${product}\n` +
            `Частное: ${numX} / ${numY} = ${quotient}`;

        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end(responseText);
    }

    // 04 /parameter/x/y
    else if (pathname.startsWith('/parameter/')) {
        const parts = pathname.split('/').filter(part => part !== '');
        
        if (parts.length === 3) {
            const x = parts[1];
            const y = parts[2];

            const numX = parseFloat(x);
            const numY = parseFloat(y);

            if (!isNaN(numX) && !isNaN(numY)) {
                const sum = numX + numY;
                const difference = numX - numY;
                const product = numX * numY;
                const quotient = numY !== 0 ? numX / numY : 'деление на ноль';

                const responseText = 
                    `x = ${numX}, y = ${numY}\n\n` +
                    `Сумма: ${numX} + ${numY} = ${sum}\n` +
                    `Разность: ${numX} - ${numY} = ${difference}\n` +
                    `Произведение: ${numX} * ${numY} = ${product}\n` +
                    `Частное: ${numX} / ${numY} = ${quotient}`;

                res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
                res.end(responseText);
            } else {                
                res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
                res.end(`URI: ${req.url}`);
            }
        } else {
            res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Используйте формат: /parameter/x/y');
        }
    }

    // 05 /close
    else if (pathname === '/close') {        
        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Сервер будет закрыт через 10 секунд');
        
        setTimeout(() => {
            console.log('Закрываем сервер');
            server.close(() => {
                console.log('Сервер успешно закрыт');
                process.exit(0);
            });
        }, 10000);
    }

    // 06 /socket
    else if (pathname === '/socket') {        
        const clientSocket = req.socket;
        const serverSocket = clientSocket.localAddress ? clientSocket : null;

        const clientInfo = {
            ip: clientSocket.remoteAddress,
            port: clientSocket.remotePort
        };

        const serverInfo = {
            ip: serverSocket.localAddress,
            port: serverSocket.localPort
        };

        const responseText =            
            'Клиент:\n' +
            `IP-адрес: ${clientInfo.ip}\n` +
            `Порт: ${clientInfo.port}\n\n` +
            'Сервер:\n' +
            `IP-адрес: ${serverInfo.ip}\n` +
            `Порт: ${serverInfo.port}`;

        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end(responseText);
    }

    // 07 /req-data
    else if (pathname === '/req-data') {
        let body = '';
        let chunkCount = 0;

        req.on('data', (chunk) => {
            chunkCount++;
            body += chunk;
            console.log(`Получена порция ${chunkCount}, размер: ${chunk.length} байт`);
        });

        req.on('end', () => {
            const totalSize = Buffer.byteLength(body, 'utf8');
            
            const responseText =                 
                `Всего порций данных: ${chunkCount}\n` +
                `Общий размер данных: ${totalSize} байт\n` +
                `Длина текста: ${body.length} символов\n` +
                `Метод запроса: ${req.method}`;         

            res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end(responseText);

            console.log(`Обработка завершена. Всего порций: ${chunkCount}, общий размер: ${totalSize} байт`);
        });
    }

    // 08 /resp-status
    else if (pathname === '/resp-status') {
        const code = query.code;
        const mess = query.mess;

        if (!code) {
            res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Ошибка: укажите параметр code');
            return;
        }

        const statusCode = parseInt(code);
        
        if (isNaN(statusCode)) {
            res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Ошибка: код должен быть числом');
            return;
        }

        const statusMessage = mess || http.STATUS_CODES[statusCode] || 'Unknown Status';

        res.writeHead(statusCode, { 
            'Content-Type': 'text/plain; charset=utf-8',
            'X-Custom-Status': 'set-by-user'
        });
        
        const responseText = 
            `Статус ответа: ${statusCode} ${statusMessage}\n` +
            `Стандартное описание: ${http.STATUS_CODES[statusCode] || 'неизвестно'}\n` +
            `URL: ${req.url}`;

        res.end(responseText);
    }

    // 09 /formparameter
    else if (pathname === '/formparameter') {
        if (req.method === 'GET') {
            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            res.end(`<!DOCTYPE html>
<html>
<head>
    <title>Форма с разными полями</title>
    <meta charset="utf-8">
</head>
<body>
    <h1>Тестовая форма</h1>
    <form method="POST" action="/formparameter">
        <p>Текстовое поле: <input type="text" name="textfield" value="Пример текста"></p>        
        <p>Числовое поле: <input type="number" name="numberfield" value="25"></p>        
        <p>Дата: <input type="date" name="datefield" value="2024-01-15"></p>        
        <p>Чекбоксы:</p>
        <input type="checkbox" name="checkbox1" value="option1" checked> Опция 1<br>
        <input type="checkbox" name="checkbox2" value="option2"> Опция 2<br>
        <input type="checkbox" name="checkbox3" value="option3" checked> Опция 3<br>        
        <p>Радиокнопки:</p>
        <input type="radio" name="radiofield" value="radio1" checked> Радио 1<br>
        <input type="radio" name="radiofield" value="radio2"> Радио 2<br>
        <input type="radio" name="radiofield" value="radio3"> Радио 3<br>        
        <p>Textarea:</p>
        <textarea name="textarea" rows="3" cols="30">Многострочный текст</textarea>        
        <p>Две кнопки Submit с одним именем:</p>
        <input type="submit" name="submitbtn" value="Сохранить">
        <input type="submit" name="submitbtn" value="Отправить">
    </form>
    <h2>Скрипт: <span 
        id="result"></span></h2>
        <h2>Location:</h2>
    <div id="location-info">
        <script>
            const locInfo = document.getElementById('location-info');
            let html = 'Полный URL:' + location.href + '<br>';
            html += 'Протокол: ' + location.protocol + '<br>';
            html += 'Хост: ' + location.host + '<br>';
            html += 'Порт: ' + location.port + '<br>';
            html += 'Путь:' + location.pathname + '<br>';
            html += 'Origin: ' + location.origin + '<br>';
            html += 'Хост + порт: ' + location.hostname + ':' + location.port;
            locInfo.innerHTML = html;
        </script>
    </div>
</body>
</html>`);
        } else if (req.method === 'POST') {
            let body = '';
            
            req.on('data', chunk => {
                body += chunk.toString();
            });
            
            req.on('end', () => {
                const formData = querystring.parse(body);
                                
                let responseText = 'ПОЛУЧЕННЫЕ ДАННЫЕ ФОРМЫ\n\n';
                
                for (const [key, value] of Object.entries(formData)) {
                    responseText += `${key}: ${value}\n`;
                }
                
                res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
                res.end(responseText);
            });
        } else {
            res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Метод не поддерживается');
        }
    }

    // 10 /json
    else if (pathname === '/json') {
        if (req.method === 'POST') {
            let body = '';

            req.on('data', chunk => {
                body += chunk.toString();
            });

            req.on('end', () => {
                try {                    
                    const requestData = JSON.parse(body);

                    if (!requestData.x || !requestData.y || !requestData.s || !requestData.o || !requestData.m) {
                        throw new Error('Неверная структура JSON');
                    }

                    const x_plus_y = requestData.x + requestData.y;
                    const concatenation = requestData.s + ": " + requestData.o.surname + ", " + requestData.o.name;
                    const length_m = requestData.m.length;

                    const responseData = {
                        "__comment": "Ответ.Лабораторная работа 8/10",
                        "x_plus_y": x_plus_y,
                        "Concatination_s_o": concatenation,
                        "Length_m": length_m
                    };

                    res.writeHead(200, {
                        'Content-Type': 'application/json; charset=utf-8'
                    });
                    res.end(JSON.stringify(responseData, null, 2));

                } catch (error) {
                    res.writeHead(400, {
                        'Content-Type': 'application/json; charset=utf-8'
                    });
                    res.end(JSON.stringify({
                        error: 'Неверный JSON формат',
                        message: error.message
                    }));
                }
            });

        } else {
            res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Только POST запросы поддерживаются');
        }
    }

    // 11 /xml
    else if (pathname === '/xml') {
        if (req.method === 'POST') {
            let body = '';

            req.on('data', chunk => {
                body += chunk.toString();
            });

            req.on('end', () => {
                try {
                    const requestIdMatch = body.match(/<request\s+id\s*=\s*"([^"]*)"/);
                    const requestId = requestIdMatch ? requestIdMatch[1] : "unknown";

                    const xValues = [];
                    const xMatches = body.match(/<x\s+value\s*=\s*"([^"]*)"\s*\/>/g) || [];
                    xMatches.forEach(match => {
                        const value = match.match(/value\s*=\s*"([^"]*)"/)[1];
                        xValues.push(parseFloat(value));
                    });

                    const mValues = [];
                    const mMatches = body.match(/<m\s+value\s*=\s*"([^"]*)"\s*\/>/g) || [];
                    mMatches.forEach(match => {
                        const value = match.match(/value\s*=\s*"([^"]*)"/)[1];
                        mValues.push(value);
                    });

                    const sum = xValues.reduce((total, num) => total + num, 0);
                    const concat = mValues.join('');

                    const responseXml = 
`<response id="33" request="${requestId}">
    <!-- ответ на запрос ${requestId} -->
    <sum element="x" result="${sum}" />
    <!-- сумма значений элементов x -->
    <concat element="m" result="${concat}" />
    <!-- конкатенация всех элементов m -->
</response>`;

                    res.writeHead(200, {
                        'Content-Type': 'application/xml; charset=utf-8'
                    });
                    res.end(responseXml);

                } catch (error) {
                    res.writeHead(400, {
                        'Content-Type': 'application/xml; charset=utf-8'
                    });
                    const errorXml = `<?xml version="1.0" encoding="UTF-8"?>
<error>
    <message>${error.message}</message>
</error>`;
                    res.end(errorXml);
                }
            });

        } else {
            res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Только POST запросы поддерживаются');
        }
    }

    // 12 /files
    else if (pathname === '/files') {
        if (req.method !== 'GET' ) {
            mainHandler.writeHTTP405(res);
        }
        mainHandler.getFilesCount((count) => {
            mainHandler.getAllFiles((fileList) => {                
                res.writeHead(200, {
                    'Content-Type': 'text/plain; charset=utf-8',
                    'X-static-files-count': count
                });
                
                let responseText = `Количество файлов в папке static: ${count}\n\n`;
                responseText += 'Файлы:\n';
                
                if (fileList.length > 0) {
                    fileList.forEach(file => {
                        responseText += `- ${file}\n`;
                    });
                } else {
                    responseText += 'Файлы не найдены\n';
                }
                
                res.end(responseText);
            });
        });
    }

    // 13 /files/filename 
    else if (pathname.startsWith('/files/')) {
        if (req.method !== 'GET') {
            mainHandler.writeHTTP405(res);
        }
        const filename = pathname.substring(7);
        
        if (!filename) {
            res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Укажите имя файла');
            return;
        }

        console.log(`Запрос файла: ${filename}`);
        mainHandler.sendFileByName(filename, res);
    }

    // 14 /upload
    else if (pathname === '/upload') {
        if (req.method === 'GET') {            
            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            res.end(mainHandler.getUploadForm());
        } else if (req.method === 'POST') {            
            mainHandler.handleFileUpload(req, res);
        } else {
            mainHandler.writeHTTP405(res);
        }
    }

    else {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Страница не найдена');
    }
});

server.on('connection', (socket) => {
    console.log(`Новое соединение`);
    
    socket.on('close', () => {
        console.log(`Соединение закрыто`);
    });
});

server.keepAliveTimeout = 5000;

server.listen(3000, () => {
    console.log('Сервер 08-00 запущен на http://localhost:3000');
    console.log('Доступные endpoints:');
    console.log('  GET  /connection?set=value');
    console.log('  GET  /headers');
    console.log('  GET  /parameter?x=num&y=num');
    console.log('  GET  /parameter/x/y');
    console.log('  GET  /close');
    console.log('  GET  /socket');
    console.log('  GET  /req-data');
    console.log('  GET  /resp-status?code=num&mess=text');
    console.log('  GET/POST /formparameter');
    console.log('  POST /json');
    console.log('  POST /xml');
    console.log('  GET  /files');
    console.log('  GET  /files/filename');
    console.log('  GET/POST /upload');
});