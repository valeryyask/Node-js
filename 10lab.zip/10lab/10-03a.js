const WebSocket = require('ws');

function startSimpleClient(clientName) {
    const ws = new WebSocket('ws://localhost:5000');
    
    ws.on('open', function open() {
        console.log(`[${clientName}] Connected to broadcast server`);
        
        let messageCount = 0;
        const interval = setInterval(() => {
            if (ws.readyState === WebSocket.OPEN) {
                messageCount++;
                const message = `Hello from ${clientName} - message ${messageCount}`;
                ws.send(message);
                console.log(`[${clientName}] Sent: ${message}`);
            }
        }, 4000);

        setTimeout(() => {
            clearInterval(interval);
            ws.close();
            console.log(`[${clientName}] Finished testing`);
        }, 30000);
    });

    ws.on('message', function message(data) {
        console.log(`[${clientName}] Received: ${data}`);
    });

    ws.on('close', function close() {
        console.log(`[${clientName}] Disconnected`);
    });

    ws.on('error', function error(err) {
        console.log(`[${clientName}] Error: ${err}`);
    });
}

if (require.main === module) {
    const clientName = process.argv[2] || 'SimpleClient';
    startSimpleClient(clientName);
}