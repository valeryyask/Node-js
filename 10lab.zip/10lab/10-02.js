const WebSocket = require('ws');

function startWebSocketClient(clientId = 1) {
    const ws = new WebSocket('ws://localhost:4000');
    let messageCount = 0;
    let intervalId = null;

    ws.on('open', function open() {
        console.log(`[Client ${clientId}] Connected to WebSocket server`);
        
        intervalId = setInterval(() => {
            if (ws.readyState === WebSocket.OPEN) {
                messageCount++;
                const message = `10-01-client: ${messageCount}`;
                ws.send(message);
                console.log(`[Client ${clientId}] Sent: ${message}`);
            }
        }, 3000);
    });

    ws.on('message', function message(data) {
        console.log(`[Client ${clientId}] Received: ${data}`);
    });

    ws.on('error', function error(err) {
        console.log(`[Client ${clientId}] Error: ${err}`);
    });

    ws.on('close', function close() {
        console.log(`[Client ${clientId}] Disconnected from server`);
        if (intervalId) clearInterval(intervalId);
    });

    setTimeout(() => {
        if (ws.readyState === WebSocket.OPEN) {
            console.log(`[Client ${clientId}] Automatically stopping after 25 seconds`);
            ws.close();
        }
    }, 25000);
}

if (require.main === module) {
    const clientId = process.argv[2] || 1;
    startWebSocketClient(parseInt(clientId));
}

module.exports = startWebSocketClient;