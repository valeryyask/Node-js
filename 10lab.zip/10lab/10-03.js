const WebSocket = require('ws');
const http = require('http');
const path = require('path');
const fs = require('fs');

const httpServer = http.createServer((req, res) => {
    if (req.method === 'GET' && req.url === '/status') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(`
            <html>
                <head><title>Broadcast Server Status</title></head>
                <body>
                    <h1>WebSocket Broadcast Server 10-03</h1>
                    <p>Status: Running</p>
                    <p>Port: 5000</p>
                    <p>Connected clients: ${clients.size}</p>
                    <p>Total messages broadcasted: ${totalMessagesBroadcasted}</p>
                </body>
            </html>
        `);
    } else {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('Broadcast WebSocket Server 10-03 is running on ws://localhost:5000\nVisit /status for details');
    }
});

httpServer.listen(3001, () => {
    console.log('HTTP Status server running on http://localhost:3001/status');
});

const wss = new WebSocket.Server({ port: 5000 }, () => {
    console.log('Broadcast WebSocket Server 10-03 running on ws://localhost:5000');
});

const clients = new Set();
let clientCounter = 0;
let totalMessagesBroadcasted = 0;

wss.on('connection', (ws) => {
    clientCounter++;
    const clientId = clientCounter;
    const clientInfo = {
        id: clientId,
        connectTime: new Date().toLocaleTimeString(),
        messageCount: 0
    };
    
    console.log(`Client ${clientId} connected`);
    clients.add(ws);
    
    const welcomeMsg = `SERVER: Добро пожаловать! Вы клиент #${clientId}. Всего клиентов: ${clients.size}`;
    ws.send(welcomeMsg);
    
    broadcast(`SERVER: Клиент #${clientId} присоединился к чату. Всего клиентов: ${clients.size}`, ws);

    ws.on('message', (message) => {
        try {
            const messageStr = message.toString();
            clientInfo.messageCount++;
            console.log(`[Client ${clientId}] → ${messageStr}`);
            
            const broadcastMsg = `[Client ${clientId}]: ${messageStr}`;
            broadcast(broadcastMsg, ws);
            totalMessagesBroadcasted++;
            
        } catch (error) {
            console.log(`Error processing message from client ${clientId}:`, error);
        }
    });

    ws.on('close', () => {
        console.log(`Client ${clientId} disconnected`);
        clients.delete(ws);
        broadcast(`SERVER: Клиент #${clientId} покинул чат. Осталось клиентов: ${clients.size}`, null);
    });

    ws.on('error', (error) => {
        console.log(`Client ${clientId} error:`, error);
        clients.delete(ws);
    });
});


function broadcast(message, excludeSender = null) {
    let sentCount = 0;
    clients.forEach(client => {
        if (client !== excludeSender && client.readyState === WebSocket.OPEN) {
            client.send(message);
            sentCount++;
        }
    });
    console.log(`Broadcast: "${message}" → ${sentCount} clients`);
}

setInterval(() => {
    if (clients.size > 0) {
        const systemMsg = `SERVER: Статистика - Клиентов онлайн: ${clients.size}, Всего сообщений: ${totalMessagesBroadcasted}`;
        broadcast(systemMsg);
    }
}, 15000);

console.log('Broadcast server initialized');
console.log('WebSocket: ws://localhost:5000');
console.log('HTTP Status: http://localhost:3001/status');