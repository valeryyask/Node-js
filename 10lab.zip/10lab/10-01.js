const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');

const httpServer = http.createServer((req, res) => {
    if (req.method === 'GET' && req.url === '/start') {
        const filePath = path.join(__dirname, '10-01.html');
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(500);
                res.end('Error loading HTML file');
                return;
            }
            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            res.end(data);
        });
    } else {
        res.writeHead(400);
        res.end('Bad Request');
    }
});

httpServer.listen(3000, () => {
    console.log('HTTP Server running on http://localhost:3000');
});

const wss = new WebSocket.Server({ port: 4000 }, () => {
    console.log('WebSocket Server running on ws://localhost:4000');
});

let clientMessageCount = 0;
let serverMessageCount = 0;
let clientNumber = 0;

wss.on('connection', (ws) => {
    console.log('New client connected');
    clientMessageCount = 0;
    serverMessageCount = 0;
    clientNumber = 0;

    ws.on('message', (message) => {
        const messageStr = message.toString();
        console.log(`Received from client: ${messageStr}`);
        
        const match = messageStr.match(/10-01-client: (\d+)/);
        if (match) {
            clientNumber = parseInt(match[1]);
        }
        
        clientMessageCount++;
    });

    const serverInterval = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
            serverMessageCount++;
            const serverMessage = `10-01-server: ${clientNumber}->${serverMessageCount}`;
            ws.send(serverMessage);
            console.log(`Sent to client: ${serverMessage}`);
        }
    }, 5000);

    ws.on('close', () => {
        console.log('Client disconnected');
        clearInterval(serverInterval);
    });

    ws.on('error', (error) => {
        console.log('WebSocket error:', error);
        clearInterval(serverInterval);
    });
});