
const nodemailer = require('nodemailer');


const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: "val.yskvch@gmail.com", 
    pass: "rblv uyna dvyk vcel" 
  },
});


function send(messageText) {
  transporter.sendMail({
    from: '"Приложение" <val.yskvch@gmail.com>',
    to: 'val.yskvch@gmail.com', 
    subject: 'msg',
    html: messageText,
  }, (err, reply) => {
    if (err) {
      console.log('Error sending email:', err);
    } else {
      console.log('Email sent successfully!');
    }
  });
}

module.exports = { send };