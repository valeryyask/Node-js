const http = require('http');
const url = require('url');
const fs = require('fs');
const data_module = require('./DB_module'); 
const PORT = 5000;
const db = new data_module.DB();

const serverStats = {
    start_time: null,
    finish_time: null,
    request_count: 0,
    commit_count: 0
};

let stopTimeout = null;
let commitInterval = null;
let statisticsTimeout = null;

db.on('GET', async (request, response) => {
    response.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    response.end(JSON.stringify(db.select()));
});

db.on('POST', async (request, response) => {
    request.on('data', (data) => {
        let dat = JSON.parse(data);
        db.insert(dat);
        response.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        response.end(JSON.stringify(dat));
    });
});

db.on('PUT', async (request, response) => {
    request.on('data', (data) => {
        let dat = JSON.parse(data);
        db.update(dat);
        response.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        response.end(JSON.stringify(dat));
    });
});

db.on('DELETE', async (request, response) => {
    let parsedURL = url.parse(request.url, true);
    const id = parsedURL.query.id;
    if (!id) {
        response.writeHead(400, { 'content-type': 'text/html;charset=utf-8' });
        response.end('<h1>400 Bad request</h1>');
        return;
    }
    const deletedRow = db.delete(id);
    response.writeHead(200, { 'content-type': 'application/json;charset=utf-8' });
    response.end(JSON.stringify(deletedRow));
});

db.on('COMMIT', async () => {
    serverStats.commit_count = db.commit();
});

const server = http.createServer(function (request, response) {
    if (request) {
        serverStats.request_count++;
    }

    const pathname = url.parse(request.url).pathname;

    if (pathname === '/api/db') {
        db.emit(request.method, request, response);
    } 
    else if (pathname === "/api/ss") {
        response.writeHead(200, { 'content-type': 'application/json;charset=utf-8' });
        response.end(JSON.stringify(serverStats));
    } 
    else if (request.url === '/') {
        try {
            var html = fs.readFileSync('index.html');
            response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            response.end(html);
        } catch (e) {
            response.writeHead(404);
            response.end('Index.html not found');
        }
    } 
    else {
        response.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
        response.end('<h1>404, Not found</h1>');
    }
});

server.listen(PORT);

console.log(`Server running at http://localhost:${PORT}/api/db`);
console.log(`Statistics collected at http://localhost:${PORT}/api/ss`);


const prompt = () => {
    process.stdout.write('$~ ');
};

const stopServer = (delay) => {
    if (stopTimeout) clearTimeout(stopTimeout);
    
    stopTimeout = setTimeout(() => {
        console.log("\nTimeout passed. Exiting the application...");
        process.exit(0);
    }, delay);
    
    stopTimeout.unref();
    console.log(`\nServer will stop in ${delay} ms.`);
};

const startCommiting = (interval) => {
    if (commitInterval) clearInterval(commitInterval);
    
    commitInterval = setInterval(() => {
        db.emit('COMMIT');
    }, interval);
    
    commitInterval.unref(); 
    console.log(`\nCommit auto-mode started. Interval: ${interval} ms.`);
};

const collectStatistics = (collDelay) => {
    if (statisticsTimeout) clearTimeout(statisticsTimeout);

    serverStats.start_time = new Date().toLocaleString();
    serverStats.request_count = 0;
    serverStats.commit_count = 0;

    console.log(`\nStatistics collection started. Waiting ${collDelay} ms...`);

    statisticsTimeout = setTimeout(() => {
        serverStats.finish_time = new Date().toLocaleString();
        console.log("\n--- Statistics Result ---");
        console.log(serverStats);
        console.log("-------------------------");
        prompt();
    }, collDelay);

    statisticsTimeout.unref(); 
}


process.stdin.setEncoding('utf-8');
prompt(); 
process.stdin.on('data', (data) => {
    const input = data.trim().toLowerCase();

    if (!input) {
        prompt();
        return;
    }

    const args = input.split(' ');
    const command = args[0];
    const param = args[1] ? parseInt(args[1]) : null;

    switch (command) {
        case 'sd':
            if (param && !isNaN(param)) {
                stopServer(param);
            } else {
                if (stopTimeout) clearTimeout(stopTimeout);
                console.log("\nServer stop aborted.");
            }
            break;

        case 'sc': 
            if (param && !isNaN(param)) {
                startCommiting(param);
            } else {
                if (commitInterval) clearInterval(commitInterval);
                console.log("\nCommit auto-mode stopped.");
            }
            break;

        case 'ss':
            if (param && !isNaN(param)) {
                collectStatistics(param);
            } else {
                if (statisticsTimeout) clearTimeout(statisticsTimeout);
                serverStats.finish_time = new Date().toLocaleString();
                console.log("\nStatistics collection aborted.");
            }
            break;

        default:
            console.log('\nInvalid command.');
            break;
    }

    prompt();
});