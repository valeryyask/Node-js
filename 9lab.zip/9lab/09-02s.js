const http = require('http');
const url = require('url');

const server = http.createServer((req, res) => {
    if (req.method !== 'GET') {
        res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Method ' + req.method + ' not allowed');
    }
    const parsedUrl = url.parse(req.url, true);
    console.log(`GET запрос: ${req.url}`);
    
    const x = parseFloat(parsedUrl.query.x);
    const y = parseFloat(parsedUrl.query.y);
    
    if (isNaN(x) || isNaN(y)) {
        res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Ошибка: параметры x и y должны быть числами');
        return;
    }
    
    const sum = x + y;
    
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end(`Сумма ${x} + ${y} = ${sum}`);
});

server.listen(3000, () => {
    console.log('Сервер запущен на порту 3000');
});