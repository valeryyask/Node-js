const http = require('http');

const server = http.createServer((req, res) => {
    if (req.method !== 'GET') {
        res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Method ' + req.method + ' not allowed');
    }
    console.log(`GET запрос получен: ${req.url}`);
    
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('GET запрос успешно обработан');
});

server.listen(3000, () => {
    console.log('Сервер запущен на порту 3000');
});