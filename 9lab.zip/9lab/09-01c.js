const http = require('http');

const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/',
    method: 'GET'
};

const req = http.request(options, (res) => {
    console.log(`Статус ответа: ${res.statusCode}`);
    console.log(`Сообщение к статусу: ${res.statusMessage}`);

    let socket = req.socket;

    console.log(`IP-адрес сервера: ${socket.remoteAddress}`);
    console.log(`Порт сервера: ${socket.remotePort}`);
    
    let data = '';
    res.on('data', (chunk) => {
        data += chunk;
    });
    
    res.on('end', () => {
        console.log(`Данные в теле ответа: ${data}`);
    });
});

req.on('error', (error) => {
    console.log('Ошибка: ' + error.message);
});

req.end();