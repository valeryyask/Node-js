const http = require('http');
const fs = require('fs');

const fileContent = '11111\n22222\n33333\n44444';
fs.writeFileSync('MyFile1.txt', fileContent, 'utf8');
console.log('Файл MyFile1.txt создан');

let bound = 'an-an-an';
let body = `--${bound}\r\n`;
body += 'Content-Disposition: form-data; name="file"; filename="MyFile1.txt"\r\n';
body += 'Content-Type: text/plain\r\n\r\n';
body += fs.readFileSync('MyFile1.txt', 'utf8');
body += `\r\n--${bound}--\r\n`;

let options = {
    host: 'localhost',
    path: '/',
    port: 3000,
    method: 'POST',
    headers: {
        'Content-Type': 'multipart/form-data; boundary=' + bound
    }
};

const req = http.request(options, (res) => {
    let data = "";
    res.on('data', (chunk) => {
        console.log('http.request: data: body =', data += chunk.toString('utf8'));
    });
    res.on('end', () => { 
        console.log('http.request: end: body =', data); 
    });
});

req.on('error', (e) => { 
    console.log('http.request: error:', e.message);
});

req.end(body);