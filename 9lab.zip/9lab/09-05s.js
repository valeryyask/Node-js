const http = require('http');

const server = http.createServer((req, res) => {
    if (req.method !== 'POST') {
        res.writeHead(405, { 'Content-Type': 'application/xml; charset=utf-8' });
        res.end('<error>Method Not Allowed</error>');
        return;
    }

    let body = '';
    req.on('data', chunk => {
        body += chunk.toString();
    });

    req.on('end', () => {
        try {
            const requestId = body.match(/id="(\d+)"/)?.[1] || '0';
            const xValues = [...body.matchAll(/<x value="([^"]*)"\/>/g)].map(m => parseFloat(m[1]));
            const mValues = [...body.matchAll(/<m value="([^"]*)"\/>/g)].map(m => m[1]);

            const sum = xValues.reduce((acc, val) => acc + val, 0);
            const concat = mValues.join('');

            const responseId = parseInt(requestId) + 5;

            const response = `
<response id="${responseId}" request="${requestId}">
    <sum element="x" result="${sum}"/>
    <concat element="m" result="${concat}"/>
</response>`;

            res.writeHead(200, { 'Content-Type': 'application/xml; charset=utf-8' });
            res.end(response);
        } catch (e) {
            res.writeHead(400, { 'Content-Type': 'application/xml; charset=utf-8' });
            res.end('<error>Invalid XML</error>');
        }
    });
});

server.listen(3000, () => {
    console.log('Сервер запущен на порту 3000');
});