const http = require('http');

const server = http.createServer((req, res) => {
    if (req.method !== 'POST') {
        res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Method Not Allowed');
        return;
    }

    let body = '';
    req.on('data', chunk => {
        body += chunk.toString('utf8');
    });

    req.on('end', () => {
        console.log('Полученные данные:');
        console.log(body);
        
        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Файл успешно получен сервером');
    });
});

server.listen(3000, () => {
    console.log('Сервер запущен на порту 3000');
});