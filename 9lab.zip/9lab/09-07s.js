const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    if (req.method !== 'POST') {
        res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Method Not Allowed');
        return;
    }

    let body = Buffer.from('');
    req.on('data', chunk => {
        body = Buffer.concat([body, chunk]);
    });

    req.on('end', () => {
        const boundary = req.headers['content-type'].split('boundary=')[1];
        const boundaryBuffer = Buffer.from(`--${boundary}`);
        
        const startPos = body.indexOf(boundaryBuffer) + boundaryBuffer.length;
        const fileSection = body.slice(startPos);
        
        const headerEnd = fileSection.indexOf(Buffer.from('\r\n\r\n')) + 4;
        const fileData = fileSection.slice(headerEnd, fileSection.lastIndexOf(Buffer.from(`\r\n--${boundary}--`)));
        
        console.log(`Получено файловых данных: ${fileData.length} байт`);
        
        fs.writeFileSync('received.png', fileData);
        console.log('Файл сохранен как received.png');
        
        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end(`Файл успешно получен. Размер: ${fileData.length} байт`);
    });
});

server.listen(3000, () => {
    console.log('Сервер запущен на порту 3000');
});