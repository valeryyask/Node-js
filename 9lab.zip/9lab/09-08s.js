const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    if (req.method !== 'GET') {
        res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Method Not Allowed');
        return;
    }

    console.log(`GET запрос: ${req.url}`);
    
    const filePath = 'MyFile.png';
    
    if (!fs.existsSync(filePath)) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('File Not Found');
        return;
    }

    const fileStats = fs.statSync(filePath);
    res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Length': fileStats.size,
        'Content-Disposition': 'attachment; filename="MyFile.png"'
    });

    const readStream = fs.createReadStream(filePath);
    readStream.pipe(res);
});

server.listen(3000, () => {
    console.log('Сервер запущен на порту 3000');
});