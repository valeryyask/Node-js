const http = require('http');
const fs = require('fs');

const file = fs.createWriteStream("downloaded.png");

let options = {
    host: 'localhost',
    path: '/',
    port: 3000,
    method: 'GET'
}

const req = http.request(options, (res) => {
    console.log(`Статус ответа: ${res.statusCode}`);
    console.log(`Размер файла: ${res.headers['content-length']} байт`);
    
    let receivedBytes = 0;
    
    res.on('data', (chunk) => {
        receivedBytes += chunk.length;
        console.log(`Получено данных: ${receivedBytes} байт`);
    });
    
    res.pipe(file);
    
    res.on('end', () => {
        console.log('Файл успешно скачан как downloaded.png');
        
        const fileStats = fs.statSync("downloaded.png");
        console.log(`Размер скачанного файла: ${fileStats.size} байт`);
    });
});

req.on('error', (e) => {
    console.log('Ошибка:', e.message);
});

req.end();