const http = require('http');

const server = http.createServer((req, res) => {
    if (req.method !== 'POST') {
        res.writeHead(405, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ error: 'Method Not Allowed' }));
        return;
    }

    let body = '';
    req.on('data', chunk => {
        body += chunk.toString();
    });

    req.on('end', () => {
        try {
            const data = JSON.parse(body);
            const x = parseFloat(data.x);
            const y = parseFloat(data.y);
            const s = data.s;
            const m = data.m || [];
            const o = data.o || {};

            if (isNaN(x) || isNaN(y) || !s || !Array.isArray(m) || typeof o !== 'object') {
                res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
                res.end(JSON.stringify({ error: 'Неверные параметры' }));
                return;
            }

            const response = {
                x_plus_y: x + y,
                Concatination_s_o: `${s}: ${o.surname}, ${o.name}`,
                Length_m: m.length
            };

            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify(response));
        } catch (e) {
            res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify({ error: 'Неверный JSON' }));
        }
    });
});

server.listen(3000, () => {
    console.log('Сервер запущен на порту 3000');
});