const http = require('http');

const server = http.createServer((req, res) => {
    if (req.method !== 'POST') {
        res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Method Not Allowed');
        return;
    }

    let body = '';
    req.on('data', chunk => {
        body += chunk.toString();
    });

    req.on('end', () => {
        console.log('Полученное тело запроса:', body); 
        const params = new URLSearchParams(body);
        const x = parseFloat(params.get('x'));
        const y = parseFloat(params.get('y'));
        const s = params.get('s');

        if (isNaN(x) || isNaN(y) || !s) {
            res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Ошибка: неверные параметры');
            return;
        }

        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end(`Результат: x=${x}, y=${y}, s="${s}"`);
    });
});

server.listen(3000, () => {
    console.log('Сервер запущен на порту 3000');
});