const http = require('http');

const xmlData = `
<request id="28">
    <x value="1"/>
    <x value="2"/>
    <m value="a"/>
    <m value="b"/>
    <m value="c"/>
</request>`;

const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/',
    method: 'POST',
    headers: {
        'Content-Type': 'application/xml',
        'Content-Length': Buffer.byteLength(xmlData)
    }
};

const req = http.request(options, (res) => {
    console.log(`Статус ответа: ${res.statusCode}`);
    
    let responseData = '';
    res.on('data', (chunk) => {
        responseData += chunk;
    });
    
    res.on('end', () => {
        console.log(`Данные в теле ответа: ${responseData}`);            
    });
});

req.on('error', (error) => {
    console.log('Ошибка: ' + error.message);
});

req.write(xmlData);
req.end();