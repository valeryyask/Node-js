const http = require('http');

const params = new URLSearchParams({
    x: '5',
    y: '3',
    s: 'Hello'
});

const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/',
    method: 'POST',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': params.toString().length
    }
};

const req = http.request(options, (res) => {
    console.log('Полученное тело запроса:', params); 
    console.log(`Статус ответа: ${res.statusCode}`);
    console.log('Полученное тело запроса:', params.toString())
    let data = '';
    res.on('data', (chunk) => {
        data += chunk;
    });
    
    res.on('end', () => {        
        console.log(`Данные в теле ответа: ${data}`);
    });
});

req.on('error', (error) => {
    console.log('Ошибка: ' + error.message);
});

req.write(params.toString());
req.end();