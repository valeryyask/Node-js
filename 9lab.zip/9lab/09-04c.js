const http = require('http');

const requestData = {
    x: 1,
    y: 2,
    s: "Сообщение",
    m: ["a", "b", "c", "d"],
    o: {"surname": "Иванов", "name": "Иван"}
};

const data = JSON.stringify(requestData);

const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data)
    }
};

const req = http.request(options, (res) => {
    console.log(`Статус ответа: ${res.statusCode}`);
    
    let responseData = '';
    res.on('data', (chunk) => {
        responseData += chunk;
    });
    
    res.on('end', () => {
        console.log(`Данные в теле ответа: ${responseData}`);
    });
});

req.on('error', (error) => {
    console.log('Ошибка: ' + error.message);
});

req.write(data);
req.end();