const http = require('http');
const fs = require('fs');

const filePath = 'MyFile.png';
const fileData = fs.readFileSync(filePath);
console.log(`Размер файла: ${fileData.length} байт`);

let bound = 'an-an-an';
let body = Buffer.from(`--${bound}\r\n`);
body = Buffer.concat([body, Buffer.from('Content-Disposition: form-data; name="file"; filename="MyFile.png"\r\n')]);
body = Buffer.concat([body, Buffer.from('Content-Type: image/png\r\n\r\n')]);
body = Buffer.concat([body, fileData]);
body = Buffer.concat([body, Buffer.from(`\r\n--${bound}--\r\n`)]);

let options = {
    host: 'localhost',
    path: '/',
    port: 3000,
    method: 'POST',
    headers: {
        'Content-Type': 'multipart/form-data; boundary=' + bound,
        'Content-Length': body.length
    }
};

const req = http.request(options, (res) => {
    let data = "";
    res.on('data', (chunk) => {
        data += chunk.toString('utf8');
    });
    res.on('end', () => { 
        console.log('Ответ сервера:', data); 
    });
});

req.on('error', (e) => { 
    console.log('Ошибка:', e.message);
});

req.end(body);