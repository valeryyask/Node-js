const http = require('http');

const x = 5;
const y = 3;

const options = {
    hostname: 'localhost',
    port: 3000,
    path: `/?x=${x}&y=${y}`,
    method: 'GET'
};

const req = http.request(options, (res) => {
    console.log(`Статус ответа: ${res.statusCode}`);
    
    let data = '';
    res.on('data', (chunk) => {
        data += chunk;
    });
    
    res.on('end', () => {
        console.log(`Данные в теле ответа: ${data}`);
    });
});

req.on('error', (error) => {
    console.log('Ошибка: ' + error.message);
});

req.end();